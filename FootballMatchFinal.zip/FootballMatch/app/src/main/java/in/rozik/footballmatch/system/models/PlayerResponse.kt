package `in`.rozik.footballmatch.system.models

data class PlayerResponse(
    val player: List<Player>
)