package `in`.rozik.footballmatch.system.models

data class LeagueResponse(
    val countrys: List<League>
)