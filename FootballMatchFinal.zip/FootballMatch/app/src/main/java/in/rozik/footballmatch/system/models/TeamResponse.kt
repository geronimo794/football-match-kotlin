package `in`.rozik.footballmatch.system.models

data class TeamResponse(
    val teams: List<Team>
)