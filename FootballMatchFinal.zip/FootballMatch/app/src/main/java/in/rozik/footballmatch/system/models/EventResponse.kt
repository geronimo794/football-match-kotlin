package `in`.rozik.footballmatch.system.models

data class EventResponse(
    val events: List<Event>,
    val event: List<Event>
)